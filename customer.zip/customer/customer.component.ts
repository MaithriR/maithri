import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  customerForm:any;
  customers:any;
 
  constructor(private fb: FormBuilder, private bs: CustomerService) {
    this.customerForm = this.fb.group({
      customerId: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(6)]],
      customerName: ['',[Validators.required]],
      userName: ['',[Validators.required]],
      password:['',[Validators.required]],
      city:['',[Validators.required]],
      phoneNo:['',[Validators.required,Validators.minLength(10), Validators.maxLength(10),Validators.pattern]],
      emailId:['',[Validators.required,Validators.pattern]]
    },{validators:this.CustomerIdValidator()});
  }
  CustomerIdValidator() {
    return (formGroup: FormGroup) => {
      if (formGroup.controls.customerId.errors && !formGroup.controls.customerId.errors.CustomerIdValidator)
        return;
      var status = false;
      var customerId = formGroup.controls.customerId.value;
      //alert(bid.substring(0,1));
      if (customerId.substring(0, 1) != 'C') {
        status = true;
      } else {
        var num = customerId.substring(1);
        if (isNaN(num))
          status = true;
      }
      if (status)
        formGroup.controls.customerId.setErrors({ 'CustomerIdValidator': true });
      else
        formGroup.controls.customerId.setErrors(null);
    }
  }
  get form() {
    return this.customerForm.controls;
  }
  ngOnInit(): void {
    this.getAllCustomers();
  }
  getAllCustomers() {
    this.bs.getAllCustomers().subscribe((data) => {
      console.log(data);
      this.customers = data;
    });
  }
  fnSelect(customerId:any) {
    this.bs.findCustomerById(customerId).subscribe((data) => {
      console.log(data);
      this.customerForm.patchValue(data);
    });
  }
  fnFind() {
    var customerId = this.customerForm.controls.customerId.value;
    this.fnSelect(customerId);
  }

  fnAdd() {
    var customer = this.customerForm.value;   
    this.bs.addCustomer(customer).subscribe((data) => {
      console.log(data);
      this.getAllCustomers();
    });
  }
  fnModify() {
    var customer = this.customerForm.value;
    this.bs.modifyCustomer(customer).subscribe((data) => {
      console.log(data);
      this.getAllCustomers();
    });
  }
  fnDelete() {
    var customerId = this.customerForm.controls.customerId.value;
    this.bs.deleteCustomer(customerId).subscribe((data) => {
      console.log(data);
      this.getAllCustomers();
    });
  }
}

