import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { BookingService } from '../booking.service';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {
  bookingForm:any;
  bookings:any;
  constructor(private fb:FormBuilder, private bs:BookingService) { 
   this.bookingForm=this.fb.group({
     bookingId:[''],
     customerId:[''],
     hotelId:[''],
     bookingType:[''],
     arrivalDate:[''],
     departureDate:[''],
     noOfPeople:[''],
     totalAmount:[''],
   });

  }
  ngDoCheck(){
    this.read();
  }
  ngOnInit(): void {
  }
  read()
{
  this.bs.read().subscribe((data)=>{
    console.log(data);
    this.bookings=data;
  });
}
  fnAdd()
  {
    var booking=this.bookingForm.value;
    // alert('Adding '+JSON.stringify(branch));
    this.bs.add(booking).subscribe((data)=>{
      console.log(data);
      this.read();

    });
  }

  fnModify()
  {
    var booking=this.bookingForm.value;
    this.bs.modify(booking).subscribe((data)=>{
      console.log(data);
      this.read();
    });
  }

fnDelete()
{
  var bookingId=this.bookingForm.controls.bid.value;
 // var branch=this.branchForm.value;
  this.bs.delete(bookingId).subscribe((data)=>{
    console.log(data);
    this.read();

});
}
fnFind()
{
  var bookingId=this.bookingForm.controls.bookingId.value;
  this.bs.readById(bookingId).subscribe((data)=>{
    console.log(data);
   this.bookingForm.patchValue(data);
});
}
}
