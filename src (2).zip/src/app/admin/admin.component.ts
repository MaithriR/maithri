import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  adminForm: any;
  admins: any;
  constructor(private fb:FormBuilder, private as:AdminService) {
    this.adminForm=this.fb.group({
      adminId:[''],
      adminName:[''],
      userName:[''],
      password:[''],
      Rpassword:[''],

    });

   }

  ngOnInit(): void {
    this.getAllAdmins();
    document.body.classList.add('bg-img');
  }
  getAllAdmins() {
    this.as.getAllAdmins().subscribe((data) => {
      console.log(data);
      this.admins = data;
    });
  }
  
  fnSelect(adminId:any) {
    this.as.findAdminById(adminId).subscribe((data) => {
      console.log(data);
      // alert(JSON.stringify(data))
      this.adminForm.patchValue(data);
    });
  }

  fnAdd() {
    var admin = this.adminForm.value;
    // this.bs.addHotel(hotel).subscribe(this.fnCallBack);    
    this.as.addAdmin(admin).subscribe((data) => {
      console.log(data);
      this.getAllAdmins();
    });
  }

  fnModify() {
    var admin = this.adminForm.value;
    this.as.modifyAdmin(admin).subscribe((data) => {
      console.log(data);
      this.getAllAdmins();
    });
  }

  fnDelete() {
    var adminId = this.adminForm.controls.adminId.value;
    this.as.deleteAdmin(adminId).subscribe((data) => {
      console.log(data);
      this.getAllAdmins();
    });
  }
}
